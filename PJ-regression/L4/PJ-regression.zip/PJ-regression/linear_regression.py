"""
线性回归课堂实践代码（最终教学版 V2）
--------------------------------------
说明：
1. 所有工具模块均已实现并封装完成。
2. 学生只需要在 main() 中完成案例配置：
   - 填写 CSV 路径
   - 指定用于拟合的自变量列名 x_cols
   - 指定因变量列名 y_col
   - 指定用于绘图展示的参考自变量 plot_x_cols
3. 运行流程固定为：
   load_case -> run -> collect_data -> plot

设计原则：
- 模型拟合时，x_cols 可以包含任意数量的自变量。
- 绘图时，只允许选择 1 个或 2 个参考自变量 plot_x_cols。
- 当 plot_x_cols 只有 1 个变量时，输出二维参考拟合图。
- 当 plot_x_cols 有 2 个变量时，输出三维参考拟合平面图。
- 若模型实际使用的自变量超过 2 个，其余变量在绘图时固定为训练集均值。

依赖：
    pandas
    numpy
    matplotlib
    scikit-learn
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score


@dataclass
class CaseConfig:
    case_name: str
    csv_path: str
    x_cols: List[str]
    y_col: str
    plot_x_cols: List[str]
    output_dir: str = "outputs"


class RegressionTrainer:
    """
    统一封装的线性回归训练器。

    设计说明：
    - x_cols 控制模型拟合时实际使用的全部自变量。
    - plot_x_cols 仅控制绘图展示所参考的自变量。
    - plot_x_cols 必须是 x_cols 的子集，且长度只能为 1 或 2。
    - 若 x_cols 的维度高于 plot_x_cols，其余变量在绘图时固定为训练集均值。
    """

    def __init__(self) -> None:
        self.config: Optional[CaseConfig] = None
        self.df: Optional[pd.DataFrame] = None
        self.X_df: Optional[pd.DataFrame] = None
        self.X: Optional[np.ndarray] = None
        self.y: Optional[np.ndarray] = None
        self.model: Optional[LinearRegression] = None
        self.y_pred: Optional[np.ndarray] = None
        self.result_table: Optional[pd.DataFrame] = None
        self.feature_means: Optional[pd.Series] = None

    # ------------------------------------------------------------------
    # 基础校验
    # ------------------------------------------------------------------
    def _assert_config_is_ready(self) -> None:
        if self.config is None:
            raise RuntimeError("尚未加载案例，请先调用 load_case()。")

    def _assert_has_run(self) -> None:
        if self.model is None or self.y_pred is None:
            raise RuntimeError("模型尚未训练，请先调用 run()。")

    @staticmethod
    def _assert_user_filled(text: str, field_name: str) -> None:
        placeholder_tokens = {"请填写", "your_", "TODO", "todo", "路径", "列名"}
        if not text or any(token in text for token in placeholder_tokens):
            raise ValueError(f"{field_name} 尚未按要求填写。")

    @staticmethod
    def _sanitize_filename(text: str) -> str:
        valid = []
        for ch in text:
            if ch.isalnum() or ch in {'_', '-'}:
                valid.append(ch)
            else:
                valid.append('_')
        return ''.join(valid).strip('_') or 'plot'

    # ------------------------------------------------------------------
    # 加载案例
    # ------------------------------------------------------------------
    def load_case(
        self,
        case_name: str,
        csv_path: str,
        x_cols: List[str],
        y_col: str,
        plot_x_cols: List[str],
        output_dir: str = "outputs",
    ) -> "RegressionTrainer":
        """
        加载 CSV 案例并完成字段校验。
        """
        self._assert_user_filled(case_name, "case_name")
        self._assert_user_filled(csv_path, "csv_path")
        self._assert_user_filled(y_col, "y_col")

        if not isinstance(x_cols, list) or len(x_cols) == 0:
            raise ValueError("x_cols 必须是非空列表。")
        for i, col in enumerate(x_cols):
            self._assert_user_filled(col, f"x_cols[{i}]")

        if not isinstance(plot_x_cols, list) or len(plot_x_cols) == 0:
            raise ValueError("plot_x_cols 必须是非空列表。")
        if len(plot_x_cols) not in (1, 2):
            raise ValueError("plot_x_cols 只能包含 1 个或 2 个自变量，用于统一生成教学版图像。")
        for i, col in enumerate(plot_x_cols):
            self._assert_user_filled(col, f"plot_x_cols[{i}]")

        if not set(plot_x_cols).issubset(set(x_cols)):
            raise ValueError("plot_x_cols 必须是 x_cols 的子集。")

        csv_file = Path(csv_path)
        if not csv_file.exists():
            raise FileNotFoundError(f"未找到 CSV 文件：{csv_file}")

        df = pd.read_csv(csv_file)

        required_cols = list(dict.fromkeys(list(x_cols) + [y_col]))
        missing_cols = [c for c in required_cols if c not in df.columns]
        if missing_cols:
            raise ValueError(f"CSV 中缺少列：{missing_cols}")

        clean_df = df[required_cols].dropna().copy()

        self.config = CaseConfig(
            case_name=case_name,
            csv_path=str(csv_file),
            x_cols=x_cols,
            y_col=y_col,
            plot_x_cols=plot_x_cols,
            output_dir=output_dir,
        )
        self.df = clean_df
        self.X_df = clean_df[x_cols].copy()
        self.X = self.X_df.to_numpy(dtype=float)
        self.y = clean_df[y_col].to_numpy(dtype=float)
        self.feature_means = self.X_df.mean(axis=0)

        return self

    # ------------------------------------------------------------------
    # 训练
    # ------------------------------------------------------------------
    def run(self) -> "RegressionTrainer":
        """
        训练线性回归模型。
        """
        self._assert_config_is_ready()

        self.model = LinearRegression()
        self.model.fit(self.X_df, self.y)
        self.y_pred = self.model.predict(self.X_df)

        result = self.df.copy()
        result["prediction"] = np.round(self.y_pred, 4)
        result["residual"] = np.round(result[self.config.y_col] - result["prediction"], 4)
        self.result_table = result

        return self

    # ------------------------------------------------------------------
    # 结果整理与控制台输出
    # ------------------------------------------------------------------
    def collect_data(self, preview_rows: int = 10) -> pd.DataFrame:
        """
        在控制台输出提交所需的核心数据，并返回完整结果表。
        """
        self._assert_config_is_ready()
        self._assert_has_run()

        mse = mean_squared_error(self.y, self.y_pred)
        rmse = float(np.sqrt(mse))
        r2 = r2_score(self.y, self.y_pred)

        coef_series = pd.Series(
            np.round(self.model.coef_, 6),
            index=self.config.x_cols,
            name="coefficient",
        )

        print("=" * 72)
        print("线性回归运行结果")
        print("=" * 72)
        print(f"案例名称: {self.config.case_name}")
        print(f"CSV 路径: {self.config.csv_path}")
        print(f"用于拟合的自变量: {', '.join(self.config.x_cols)}")
        print(f"用于绘图的参考自变量: {', '.join(self.config.plot_x_cols)}")
        print(f"因变量: {self.config.y_col}")
        print(f"样本数: {len(self.df)}")
        print("-" * 72)
        print("回归系数：")
        print(coef_series.to_string())
        print(f"截距(intercept): {self.model.intercept_:.6f}")
        print("-" * 72)
        print(f"R^2  : {r2:.6f}")
        print(f"MSE  : {mse:.6f}")
        print(f"RMSE : {rmse:.6f}")
        print("-" * 72)
        print("前若干条预测结果：")
        print(self.result_table.head(preview_rows).to_string(index=False))
        print("=" * 72)

        return self.result_table.copy()

    # ------------------------------------------------------------------
    # 绘图
    # ------------------------------------------------------------------
    def plot(self) -> None:
        """
        根据 plot_x_cols 自动绘图，并保存为 PNG 文件。
        """
        self._assert_config_is_ready()
        self._assert_has_run()

        output_dir = Path(self.config.output_dir) / self.config.case_name
        output_dir.mkdir(parents=True, exist_ok=True)

        if len(self.config.plot_x_cols) == 1:
            self._plot_reference_curve(output_dir)
        elif len(self.config.plot_x_cols) == 2:
            self._plot_reference_plane(output_dir)

        self._plot_actual_vs_pred(output_dir)
        print(f"图片已保存至：{output_dir.resolve()}")

    def _build_reference_frame(self, overrides: dict[str, np.ndarray | float]) -> pd.DataFrame:
        base = pd.DataFrame(
            np.tile(self.feature_means.to_numpy(), (len(next(iter(overrides.values()))) if isinstance(next(iter(overrides.values())), np.ndarray) else 1, 1)),
            columns=self.config.x_cols,
        )
        for col, values in overrides.items():
            base[col] = values
        return base

    def _plot_reference_curve(self, output_dir: Path) -> None:
        x_name = self.config.plot_x_cols[0]
        y_name = self.config.y_col
        x = self.df[x_name].to_numpy(dtype=float)
        y = self.df[y_name].to_numpy(dtype=float)

        x_grid = np.linspace(x.min(), x.max(), 200)
        reference_df = pd.DataFrame(
            np.tile(self.feature_means.to_numpy(), (len(x_grid), 1)),
            columns=self.config.x_cols,
        )
        reference_df[x_name] = x_grid
        y_hat_grid = self.model.predict(reference_df[self.config.x_cols])

        plt.figure(figsize=(8, 5))
        plt.scatter(x, y, alpha=0.82, label="observed")
        plt.plot(x_grid, y_hat_grid, linewidth=2.2, label="reference fit")
        plt.xlabel(x_name)
        plt.ylabel(y_name)
        if len(self.config.x_cols) == 1:
            title = f"Linear Regression Fit: {x_name} -> {y_name}"
        else:
            held_cols = [c for c in self.config.x_cols if c != x_name]
            title = f"Reference Fit by {x_name} (other variables fixed at mean)"
        plt.title(title)
        plt.legend()
        plt.tight_layout()
        plot_name = f"reference_curve_{self._sanitize_filename(x_name)}.png"
        plt.savefig(output_dir / plot_name, dpi=200)
        plt.close()

    def _plot_reference_plane(self, output_dir: Path) -> None:
        x1_name, x2_name = self.config.plot_x_cols
        y_name = self.config.y_col

        x1 = self.df[x1_name].to_numpy(dtype=float)
        x2 = self.df[x2_name].to_numpy(dtype=float)
        y = self.df[y_name].to_numpy(dtype=float)

        x1_grid = np.linspace(x1.min(), x1.max(), 35)
        x2_grid = np.linspace(x2.min(), x2.max(), 35)
        xx1, xx2 = np.meshgrid(x1_grid, x2_grid)

        reference_df = pd.DataFrame(
            np.tile(self.feature_means.to_numpy(), (xx1.size, 1)),
            columns=self.config.x_cols,
        )
        reference_df[x1_name] = xx1.ravel()
        reference_df[x2_name] = xx2.ravel()
        zz = self.model.predict(reference_df[self.config.x_cols]).reshape(xx1.shape)

        fig = plt.figure(figsize=(8, 6))
        ax = fig.add_subplot(111, projection="3d")
        ax.scatter(x1, x2, y, alpha=0.88, label="observed")
        ax.plot_surface(xx1, xx2, zz, alpha=0.42)
        ax.set_xlabel(x1_name)
        ax.set_ylabel(x2_name)
        ax.set_zlabel(y_name)
        if len(self.config.x_cols) == 2:
            title = f"Reference Plane: {x1_name}, {x2_name} -> {y_name}"
        else:
            title = (
                f"Reference Plane by {x1_name}, {x2_name} "
                f"(other variables fixed at mean)"
            )
        ax.set_title(title)
        plt.tight_layout()
        plot_name = (
            f"reference_plane_{self._sanitize_filename(x1_name)}_"
            f"{self._sanitize_filename(x2_name)}.png"
        )
        plt.savefig(output_dir / plot_name, dpi=200)
        plt.close()

    def _plot_actual_vs_pred(self, output_dir: Path) -> None:
        y_true = self.y
        y_pred = self.y_pred

        lim_min = float(min(y_true.min(), y_pred.min()))
        lim_max = float(max(y_true.max(), y_pred.max()))

        plt.figure(figsize=(6.5, 6))
        plt.scatter(y_true, y_pred, alpha=0.85)
        plt.plot([lim_min, lim_max], [lim_min, lim_max], linewidth=2)
        plt.xlabel("Actual")
        plt.ylabel("Predicted")
        plt.title("Actual vs Predicted")
        plt.tight_layout()
        plt.savefig(output_dir / "actual_vs_predicted.png", dpi=200)
        plt.close()


def main() -> None:
    # ==========================================================
    # 学生仅需修改本区
    # ==========================================================
    case_name = "请填写案例名称"
    csv_path = "请填写CSV路径"

    # 用于拟合的全部自变量，可以是 1 个、2 个或更多
    # 例如：
    # x_cols = ["area"]
    # x_cols = ["area", "rooms", "floor", "age"]
    x_cols = ["请填写用于拟合的x列名"]

    # 因变量
    y_col = "请填写y列名"

    # 用于绘图展示的参考自变量，只能写 1 个或 2 个，且必须来自 x_cols
    # 例如：
    # plot_x_cols = ["area"]
    # plot_x_cols = ["area", "rooms"]
    plot_x_cols = ["请填写用于绘图的x列名"]

    # ==========================================================

    trainer = RegressionTrainer()
    trainer.load_case(
        case_name=case_name,
        csv_path=csv_path,
        x_cols=x_cols,
        y_col=y_col,
        plot_x_cols=plot_x_cols
    )
    trainer.run()
    trainer.collect_data()
    trainer.plot()


if __name__ == "__main__":
    main()
