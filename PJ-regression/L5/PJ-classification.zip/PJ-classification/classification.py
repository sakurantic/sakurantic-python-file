"""
分类算法课堂实践代码（教学版）
--------------------------------
学生主要在 main() 中填写：
1. data_path：分类数据文件路径
2. case_name：案例名称
3. PARAM_GRIDS：KNN / SVM / DecisionTree 的参数网格

GeneralClassifier 已封装：
load_case -> run -> collect_data -> plot

默认约定：
- 数据最后一列为标签列，其他列为特征列。
- 如标签列不是最后一列，可在 main 中填写 target_col。
- 支持 CSV / XLSX / XLS。

重要修正：
- 模型训练时会把标签列统一编码成整数，避免部分 sklearn 版本中
  KNN 遇到字符串标签时报错。
- 控制台输出、CSV 结果表和图像中仍显示原始类别名称，便于解释。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import ListedColormap
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, StratifiedShuffleSplit, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, plot_tree


@dataclass
class ClassificationConfig:
    case_name: str
    data_path: str
    model_name: str
    target_col: str
    output_dir: str = "outputs"
    test_size: float = 0.25
    random_state: int = 42
    cv_folds: int = 5
    scoring: str = "accuracy"
    max_search_samples: int = 5000


def make_onehot_encoder() -> OneHotEncoder:
    """兼容不同 sklearn 版本。"""
    try:
        return OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        return OneHotEncoder(handle_unknown="ignore", sparse=False)


class GeneralClassifier:
    """通用分类器：KNN / SVM / DecisionTree。"""

    SUPPORTED_MODELS = {"KNN", "SVM", "DecisionTree"}

    def __init__(self) -> None:
        self.config: Optional[ClassificationConfig] = None
        self.df: Optional[pd.DataFrame] = None
        self.feature_cols: List[str] = []
        self.numeric_cols: List[str] = []
        self.categorical_cols: List[str] = []

        self.X_train: Optional[pd.DataFrame] = None
        self.X_test: Optional[pd.DataFrame] = None

        # y_train / y_test 为整数编码标签，供 sklearn 模型训练与评分使用。
        self.y_train: Optional[pd.Series] = None
        self.y_test: Optional[pd.Series] = None

        # y_train_label / y_test_label 为原始类别名称，供结果解释、保存和绘图使用。
        self.y_train_label: Optional[pd.Series] = None
        self.y_test_label: Optional[pd.Series] = None
        self.label_encoder: Optional[LabelEncoder] = None

        self.pipeline: Optional[Pipeline] = None
        self.grid_search: Optional[GridSearchCV] = None
        self.best_model: Optional[Pipeline] = None
        self.best_params_: Optional[Dict[str, Any]] = None
        self.best_score_: Optional[float] = None

        self.y_pred_encoded: Optional[np.ndarray] = None
        self.y_pred: Optional[np.ndarray] = None
        self.y_score: Optional[np.ndarray] = None
        self.metrics_: Optional[Dict[str, Any]] = None
        self.report_df: Optional[pd.DataFrame] = None
        self.preview_df: Optional[pd.DataFrame] = None
        self.output_path: Optional[Path] = None

    # ------------------------- basic utilities -------------------------
    def _assert_case_ready(self) -> None:
        if self.config is None or self.df is None or self.pipeline is None:
            raise RuntimeError("尚未加载案例，请先调用 load_case()。")

    def _assert_has_run(self) -> None:
        if self.best_model is None or self.y_pred is None or self.metrics_ is None:
            raise RuntimeError("模型尚未训练，请先调用 run()。")

    @staticmethod
    def _assert_user_filled(text: str, field_name: str) -> None:
        tokens = {"请填写", "your_", "TODO", "todo", "路径", "path"}
        if not text or any(token in str(text) for token in tokens):
            raise ValueError(f"{field_name} 尚未按要求填写。")

    @staticmethod
    def _sanitize_filename(text: str) -> str:
        text = str(text)
        text = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff=.]+", "_", text)
        text = re.sub(r"_+", "_", text).strip("_")
        return text or "default"

    @staticmethod
    def _strip_model_prefix(params: Dict[str, Any]) -> Dict[str, Any]:
        return {k.replace("model__", ""): v for k, v in params.items()}

    def _normalize_param_grid(self, param_grid: Dict[str, Any]) -> Dict[str, List[Any]]:
        """允许 main 中写 n_neighbors / C / max_depth，也允许写 model__n_neighbors。"""
        normalized: Dict[str, List[Any]] = {}
        for key, value in param_grid.items():
            values = list(value) if isinstance(value, (list, tuple, np.ndarray)) else [value]
            normalized_key = key if key.startswith("model__") else f"model__{key}"
            normalized[normalized_key] = values
        return normalized

    def _build_output_path(self) -> Path:
        """
        构建输出目录。

        目录层级固定为：outputs / case_name / model_name
        最佳参数统一保存到 best_params.json，不再写入子文件夹名称。
        """
        out = Path(self.config.output_dir) / self.config.case_name / self.config.model_name
        out.mkdir(parents=True, exist_ok=True)
        self.output_path = out
        return out

    # ------------------------- model builders -------------------------
    def _build_estimator(self, model_name: str):
        if model_name == "KNN":
            return KNeighborsClassifier()
        if model_name == "SVM":
            return SVC(probability=True, random_state=self.config.random_state)
        if model_name == "DecisionTree":
            return DecisionTreeClassifier(random_state=self.config.random_state)
        raise ValueError(f"不支持的模型名称：{model_name}")

    def _default_param_grid(self, model_name: str) -> Dict[str, List[Any]]:
        if model_name == "KNN":
            return {"n_neighbors": [3, 5, 7], "weights": ["uniform", "distance"], "p": [1, 2]}
        if model_name == "SVM":
            return {"kernel": ["linear", "rbf"], "C": [0.1, 1, 10], "gamma": ["scale", "auto"]}
        if model_name == "DecisionTree":
            return {
                "criterion": ["gini", "entropy"],
                "max_depth": [None, 3, 5, 8],
                "min_samples_split": [2, 5, 10],
                "min_samples_leaf": [1, 2, 4],
            }
        raise ValueError(f"不支持的模型名称：{model_name}")

    def _build_preprocessor(self, model_name: str) -> ColumnTransformer:
        numeric_steps = [("imputer", SimpleImputer(strategy="median"))]
        if model_name in {"KNN", "SVM"}:
            numeric_steps.append(("scaler", StandardScaler()))

        categorical_transformer = Pipeline(
            steps=[
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("onehot", make_onehot_encoder()),
            ]
        )

        return ColumnTransformer(
            transformers=[
                ("num", Pipeline(steps=numeric_steps), self.numeric_cols),
                ("cat", categorical_transformer, self.categorical_cols),
            ],
            remainder="drop",
            sparse_threshold=0.0,
        )

    def _build_pipeline(self, model_name: str) -> Pipeline:
        return Pipeline(
            steps=[
                ("preprocess", self._build_preprocessor(model_name)),
                ("model", self._build_estimator(model_name)),
            ]
        )

    # ------------------------- public API -------------------------
    def load_case(
        self,
        case_name: str,
        data_path: str,
        model_name: str,
        output_dir: str = "outputs",
        test_size: float = 0.25,
        random_state: int = 42,
        cv_folds: int = 5,
        scoring: str = "accuracy",
        max_search_samples: int = 5000,
        target_col: Optional[str] = None,
        feature_cols: Optional[Sequence[str]] = None,
    ) -> "GeneralClassifier":
        self._assert_user_filled(case_name, "case_name")
        self._assert_user_filled(data_path, "data_path")
        self._assert_user_filled(model_name, "model_name")

        if model_name not in self.SUPPORTED_MODELS:
            raise ValueError(f"model_name 必须为 {sorted(self.SUPPORTED_MODELS)} 之一。")

        data_file = Path(data_path)
        if not data_file.exists():
            raise FileNotFoundError(f"未找到数据文件：{data_file}")

        if data_file.suffix.lower() == ".csv":
            df = pd.read_csv(data_file)
        elif data_file.suffix.lower() in {".xlsx", ".xls"}:
            df = pd.read_excel(data_file)
        else:
            raise ValueError("仅支持 CSV / XLSX / XLS 文件。")

        # Mushroom 等 UCI 数据常用 ? 表示缺失值。
        df = df.replace({"?": np.nan})

        if df.shape[1] < 2:
            raise ValueError("数据至少需要包含 1 列特征和 1 列标签。")

        if target_col is None:
            target_col = str(df.columns[-1])
        if target_col not in df.columns:
            raise ValueError(f"未找到标签列：{target_col}")

        if feature_cols is None:
            feature_cols = [c for c in df.columns if c != target_col]
        else:
            missing = [c for c in feature_cols if c not in df.columns]
            if missing:
                raise ValueError(f"未找到特征列：{missing}")
            feature_cols = list(feature_cols)

        df = df.dropna(subset=[target_col]).copy()
        X = df[list(feature_cols)].copy()
        y_raw = df[target_col].astype(str).copy()

        # 删除常数列，避免无信息特征影响训练与绘图。
        nunique = X.nunique(dropna=False)
        constant_cols = nunique[nunique <= 1].index.tolist()
        if constant_cols:
            X = X.drop(columns=constant_cols)
            feature_cols = [c for c in feature_cols if c not in constant_cols]

        if not feature_cols:
            raise ValueError("剔除常数列后，已无可用特征列。")
        if y_raw.nunique(dropna=False) < 2:
            raise ValueError("标签列至少需要包含两个类别。")

        numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
        categorical_cols = [c for c in feature_cols if c not in numeric_cols]

        label_encoder = LabelEncoder()
        y_encoded = pd.Series(label_encoder.fit_transform(y_raw), index=y_raw.index, name=target_col)

        stratify_arg = y_encoded if y_encoded.value_counts().min() >= 2 else None
        X_train, X_test, y_train, y_test = train_test_split(
            X,
            y_encoded,
            test_size=test_size,
            random_state=random_state,
            stratify=stratify_arg,
        )

        y_train_label = pd.Series(
            label_encoder.inverse_transform(np.asarray(y_train, dtype=int)),
            index=y_train.index,
            name=target_col,
        )
        y_test_label = pd.Series(
            label_encoder.inverse_transform(np.asarray(y_test, dtype=int)),
            index=y_test.index,
            name=target_col,
        )

        self.config = ClassificationConfig(
            case_name=case_name,
            data_path=str(data_file),
            model_name=model_name,
            target_col=target_col,
            output_dir=output_dir,
            test_size=test_size,
            random_state=random_state,
            cv_folds=cv_folds,
            scoring=scoring,
            max_search_samples=max_search_samples,
        )
        self.df = pd.concat([X, y_raw.rename(target_col)], axis=1)
        self.feature_cols = list(feature_cols)
        self.numeric_cols = numeric_cols
        self.categorical_cols = categorical_cols
        self.X_train = X_train
        self.X_test = X_test
        self.y_train = pd.Series(y_train, index=X_train.index, name=target_col)
        self.y_test = pd.Series(y_test, index=X_test.index, name=target_col)
        self.y_train_label = y_train_label
        self.y_test_label = y_test_label
        self.label_encoder = label_encoder
        self.pipeline = self._build_pipeline(model_name)
        return self

    def _make_search_dataset(self):
        X_search = self.X_train.copy()
        y_search = self.y_train.copy()
        max_n = self.config.max_search_samples
        if len(X_search) > max_n:
            splitter = StratifiedShuffleSplit(n_splits=1, train_size=max_n, random_state=self.config.random_state)
            idx, _ = next(splitter.split(X_search, y_search))
            X_search = X_search.iloc[idx].copy()
            y_search = y_search.iloc[idx].copy()
        return X_search, y_search

    def run(self, param_grid: Optional[Dict[str, Any]] = None) -> "GeneralClassifier":
        """执行网格搜索调参与训练。param_grid 在 main 中传入。"""
        self._assert_case_ready()

        if param_grid is None:
            param_grid = self._default_param_grid(self.config.model_name)
        param_grid = self._normalize_param_grid(param_grid)

        X_search, y_search = self._make_search_dataset()
        min_class_count = int(pd.Series(y_search).value_counts().min())
        cv_folds = min(self.config.cv_folds, min_class_count)
        if cv_folds < 2:
            raise ValueError("用于交叉验证的每个类别样本数不足，无法进行网格搜索。")

        cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=self.config.random_state)
        self.grid_search = GridSearchCV(
            estimator=self.pipeline,
            param_grid=param_grid,
            scoring=self.config.scoring,
            cv=cv,
            n_jobs=1,
            refit=True,
            return_train_score=True,
            error_score="raise",
        )
        self.grid_search.fit(X_search, y_search)

        self.best_params_ = dict(self.grid_search.best_params_)
        self.best_score_ = float(self.grid_search.best_score_)

        self.best_model = clone(self.pipeline)
        self.best_model.set_params(**self.best_params_)
        self.best_model.fit(self.X_train, self.y_train)

        self.y_pred_encoded = np.asarray(self.best_model.predict(self.X_test), dtype=int)
        self.y_pred = self.label_encoder.inverse_transform(self.y_pred_encoded)
        self.y_score = self._get_scores(self.X_test)

        labels_encoded = list(range(len(self.label_encoder.classes_)))
        labels_display = [str(x) for x in self.label_encoder.classes_]
        cm = confusion_matrix(self.y_test, self.y_pred_encoded, labels=labels_encoded)

        self.metrics_ = {
            "accuracy": float(accuracy_score(self.y_test, self.y_pred_encoded)),
            "precision_macro": float(precision_score(self.y_test, self.y_pred_encoded, average="macro", zero_division=0)),
            "recall_macro": float(recall_score(self.y_test, self.y_pred_encoded, average="macro", zero_division=0)),
            "f1_macro": float(f1_score(self.y_test, self.y_pred_encoded, average="macro", zero_division=0)),
            "best_cv_score": float(self.best_score_),
            "n_train": int(len(self.X_train)),
            "n_test": int(len(self.X_test)),
            "n_features": int(len(self.feature_cols)),
            "n_classes": int(len(self.label_encoder.classes_)),
            "target_col": self.config.target_col,
            "feature_cols": self.feature_cols,
            "numeric_cols": self.numeric_cols,
            "categorical_cols": self.categorical_cols,
            "labels": labels_display,
            "label_encoding": {str(label): int(i) for i, label in enumerate(self.label_encoder.classes_)},
            "confusion_matrix": cm.tolist(),
        }

        if self._is_binary_classification() and self.y_score is not None:
            try:
                self.metrics_["roc_auc"] = float(roc_auc_score(self.y_test, self.y_score))
            except Exception:
                pass

        self.report_df = pd.DataFrame(
            classification_report(
                self.y_test,
                self.y_pred_encoded,
                labels=labels_encoded,
                target_names=labels_display,
                output_dict=True,
                zero_division=0,
            )
        ).transpose()

        preview = self.X_test.reset_index(drop=True).copy()
        preview[self.config.target_col] = self.y_test_label.reset_index(drop=True)
        preview["prediction"] = pd.Series(self.y_pred).reset_index(drop=True)
        preview["is_correct"] = preview[self.config.target_col].astype(str) == preview["prediction"].astype(str)
        self.preview_df = preview

        out = self._build_output_path()
        self._save_artifacts(out, param_grid)
        return self

    def collect_data(self, preview_rows: int = 10) -> pd.DataFrame:
        self._assert_case_ready()
        self._assert_has_run()
        clean_params = self._strip_model_prefix(self.best_params_ or {})

        print("=" * 80)
        print("分类模型运行结果")
        print("=" * 80)
        print(f"案例名称: {self.config.case_name}")
        print(f"数据路径: {self.config.data_path}")
        print(f"模型名称: {self.config.model_name}")
        print(f"标签列: {self.config.target_col}")
        print(f"特征列数: {len(self.feature_cols)}")
        print(f"特征列: {', '.join(map(str, self.feature_cols))}")
        print(f"数值型特征数: {len(self.numeric_cols)}")
        print(f"分类型特征数: {len(self.categorical_cols)}")
        print(f"训练集样本数: {len(self.X_train)}")
        print(f"测试集样本数: {len(self.X_test)}")
        print(f"类别数: {len(self.label_encoder.classes_)}")
        print(f"类别编码: {self.metrics_['label_encoding']}")
        print("-" * 80)
        print("最佳参数:")
        for k, v in clean_params.items():
            print(f"{k}: {v}")
        print("-" * 80)
        print(f"最佳交叉验证分数({self.config.scoring}): {self.best_score_:.6f}")
        print(f"Accuracy        : {self.metrics_['accuracy']:.6f}")
        print(f"Precision(macro): {self.metrics_['precision_macro']:.6f}")
        print(f"Recall(macro)   : {self.metrics_['recall_macro']:.6f}")
        print(f"F1(macro)       : {self.metrics_['f1_macro']:.6f}")
        if "roc_auc" in self.metrics_:
            print(f"ROC AUC         : {self.metrics_['roc_auc']:.6f}")
        print("-" * 80)
        print("分类报告:")
        print(self.report_df.round(4).to_string())
        print("-" * 80)
        preview_file = self.output_path / "predictions_preview.csv"
        print(f"预测结果预览已保存: {preview_file}")
        print(f"输出文件夹: {self.output_path.resolve()}")
        print("=" * 80)
        return self.preview_df.copy()

    def plot(self) -> None:
        self._assert_case_ready()
        self._assert_has_run()
        out = self.output_path

        self._plot_confusion_matrix(out)
        self._plot_class_distribution(out)

        if self._is_binary_classification() and self.y_score is not None:
            self._plot_roc_curve(out)

        if len(self.feature_cols) == 2 and len(self.numeric_cols) == 2 and len(self.categorical_cols) == 0:
            self._plot_decision_boundary(out)
        else:
            self._plot_pca_projection(out)

        if self.config.model_name == "DecisionTree":
            self._plot_decision_tree(out)

        print(f"图片已保存至：{out.resolve()}")

    # ------------------------- internal helpers -------------------------
    def _get_scores(self, X: pd.DataFrame) -> Optional[np.ndarray]:
        try:
            if self._is_binary_classification() and hasattr(self.best_model, "predict_proba"):
                probs = self.best_model.predict_proba(X)
                if probs.shape[1] == 2:
                    return probs[:, 1]
            if self._is_binary_classification() and hasattr(self.best_model, "decision_function"):
                return np.asarray(self.best_model.decision_function(X))
        except Exception:
            return None
        return None

    def _is_binary_classification(self) -> bool:
        return self.label_encoder is not None and len(self.label_encoder.classes_) == 2

    def _save_artifacts(self, out: Path, normalized_param_grid: Dict[str, List[Any]]) -> None:
        clean_params = self._strip_model_prefix(self.best_params_ or {})
        clean_grid = {k.replace("model__", ""): v for k, v in normalized_param_grid.items()}

        with open(out / "searched_param_grid.json", "w", encoding="utf-8") as f:
            json.dump(clean_grid, f, ensure_ascii=False, indent=2)

        with open(out / "best_params.json", "w", encoding="utf-8") as f:
            json.dump(clean_params, f, ensure_ascii=False, indent=2)

        with open(out / "metrics.json", "w", encoding="utf-8") as f:
            json.dump(self.metrics_, f, ensure_ascii=False, indent=2)

        self.report_df.to_csv(out / "classification_report.csv", encoding="utf-8-sig")
        self.preview_df.head(50).to_csv(out / "predictions_preview.csv", index=False, encoding="utf-8-sig")

        if self.grid_search is not None:
            cv_res = pd.DataFrame(self.grid_search.cv_results_)
            keep_cols = [
                c for c in cv_res.columns
                if c.startswith("param_")
                or c in {"mean_test_score", "std_test_score", "rank_test_score", "mean_train_score", "std_train_score"}
            ]
            cv_res[keep_cols].sort_values("rank_test_score").to_csv(
                out / "grid_search_results.csv", index=False, encoding="utf-8-sig"
            )

        joblib.dump(self.best_model, out / "best_model.joblib")

    def _plot_confusion_matrix(self, out: Path) -> None:
        labels_encoded = list(range(len(self.label_encoder.classes_)))
        display_labels = [str(x) for x in self.label_encoder.classes_]
        cm = confusion_matrix(self.y_test, self.y_pred_encoded, labels=labels_encoded)
        fig, ax = plt.subplots(figsize=(6.5, 5.5))
        ConfusionMatrixDisplay(cm, display_labels=display_labels).plot(ax=ax, colorbar=False)
        plt.title(f"Confusion Matrix - {self.config.model_name}")
        plt.tight_layout()
        plt.savefig(out / "confusion_matrix.svg", dpi=220)
        plt.close(fig)

    def _plot_class_distribution(self, out: Path) -> None:
        counts = pd.Series(self.df[self.config.target_col]).value_counts().sort_index()
        plt.figure(figsize=(7, 5))
        plt.bar(counts.index.astype(str), counts.values)
        plt.xlabel("Class")
        plt.ylabel("Count")
        plt.title(f"Class Distribution - {self.config.case_name}")
        plt.tight_layout()
        plt.savefig(out / "class_distribution.svg", dpi=220)
        plt.close()

    def _plot_roc_curve(self, out: Path) -> None:
        fpr, tpr, _ = roc_curve(self.y_test, self.y_score)
        auc_value = self.metrics_.get("roc_auc", np.nan)
        positive_label = str(self.label_encoder.classes_[1])

        plt.figure(figsize=(6.5, 5.5))
        plt.plot(fpr, tpr, linewidth=2, label=f"ROC AUC = {auc_value:.4f}")
        plt.plot([0, 1], [0, 1], linestyle="--", linewidth=1.5)
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        plt.title(f"ROC Curve - positive class: {positive_label}")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / "roc_curve.svg", dpi=220)
        plt.close()

    def _plot_decision_boundary(self, out: Path) -> None:
        x1_name, x2_name = self.feature_cols
        X_train = self.X_train[[x1_name, x2_name]].copy()
        X_test = self.X_test[[x1_name, x2_name]].copy()

        model = clone(self.best_model)
        model.fit(X_train, self.y_train)

        x1_min, x1_max = X_train[x1_name].min(), X_train[x1_name].max()
        x2_min, x2_max = X_train[x2_name].min(), X_train[x2_name].max()
        x1_pad = (x1_max - x1_min) * 0.08 if x1_max > x1_min else 1.0
        x2_pad = (x2_max - x2_min) * 0.08 if x2_max > x2_min else 1.0

        xx1, xx2 = np.meshgrid(
            np.linspace(x1_min - x1_pad, x1_max + x1_pad, 240),
            np.linspace(x2_min - x2_pad, x2_max + x2_pad, 240),
        )
        grid_df = pd.DataFrame({x1_name: xx1.ravel(), x2_name: xx2.ravel()})
        pred_grid = np.asarray(model.predict(grid_df), dtype=int)
        Z = pred_grid.reshape(xx1.shape)
        cmap = ListedColormap(plt.cm.tab10.colors[: max(3, len(self.label_encoder.classes_))])

        plt.figure(figsize=(7, 5.8))
        plt.contourf(xx1, xx2, Z, alpha=0.25, cmap=cmap)
        scatter = plt.scatter(
            X_test[x1_name], X_test[x2_name], c=self.y_test,
            cmap=cmap, edgecolors="black", alpha=0.9
        )
        plt.xlabel(x1_name)
        plt.ylabel(x2_name)
        plt.title(f"Decision Boundary - {self.config.model_name}")
        handles, _ = scatter.legend_elements()
        plt.legend(handles, [str(x) for x in self.label_encoder.classes_], title="Class")
        plt.tight_layout()
        plt.savefig(out / "decision_boundary.svg", dpi=220)
        plt.close()

    def _plot_pca_projection(self, out: Path) -> None:
        transformed = np.asarray(self.best_model.named_steps["preprocess"].transform(self.X_test))
        if transformed.shape[1] < 2:
            return

        coords = PCA(n_components=2, random_state=self.config.random_state).fit_transform(transformed)
        is_correct = np.asarray(self.y_pred_encoded) == np.asarray(self.y_test)
        cmap = ListedColormap(plt.cm.tab10.colors[: max(3, len(self.label_encoder.classes_))])

        plt.figure(figsize=(7, 5.8))
        for correct_flag, marker in [(True, "o"), (False, "x")]:
            mask = is_correct == correct_flag
            if int(mask.sum()) == 0:
                continue
            plt.scatter(
                coords[mask, 0], coords[mask, 1], c=np.asarray(self.y_test)[mask],
                cmap=cmap, marker=marker, alpha=0.85,
                label="Correct" if correct_flag else "Wrong",
            )
        plt.xlabel("PC1")
        plt.ylabel("PC2")
        plt.title(f"PCA Projection - {self.config.model_name}")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / "pca_projection.svg", dpi=220)
        plt.close()

    def _plot_decision_tree(self, out: Path) -> None:
        try:
            tree_model = self.best_model.named_steps["model"]
            preprocess = self.best_model.named_steps["preprocess"]
            feature_names = preprocess.get_feature_names_out()
            class_names = [str(x) for x in self.label_encoder.classes_]

            plt.figure(figsize=(18, 10))
            plot_tree(
                tree_model,
                feature_names=feature_names,
                class_names=class_names,
                filled=True,
                rounded=True,
                impurity=False,
                max_depth=5,
                fontsize=8,
            )
            plt.title("Decision Tree Structure (displayed max_depth = 5)")
            plt.tight_layout()
            plt.savefig(out / "decision_tree.svg", dpi=220)
            plt.close()
        except Exception as exc:
            with open(out / "decision_tree_plot_error.txt", "w", encoding="utf-8") as f:
                f.write(str(exc))


def main() -> None:
    # ==========================================================
    # 学生主要修改本区
    # ==========================================================
    data_path = r"data/mushroom.csv"
    case_name = "mushroom_classification"
    output_dir = "outputs"

    # 默认最后一列为标签列。如果不是最后一列，请填写列名，例如 target_col = "class"
    target_col = None

    # 默认使用除标签列以外的所有列。也可填写部分特征列名，例如 ["age", "income"]
    feature_cols = None

    # 评分指标可选：accuracy、f1_macro、precision_macro、recall_macro
    scoring = "accuracy"

    # 参数调整区：学生在这里尝试不同参数组合
    PARAM_GRIDS = {
        "KNN": {
            "n_neighbors": [5],
            "weights": ["uniform"],
            "p": [1],
        },
        "SVM": {
            "kernel": ["linear"],
            "C": [1],
            "gamma": ["scale"],
        },
        "DecisionTree": {
            "criterion": ["gini"],
            "max_depth": [None, 3],
            "min_samples_split": [2],
            "min_samples_leaf": [1],
        },
    }

    for model_name, param_grid in PARAM_GRIDS.items():
        classifier = GeneralClassifier()
        classifier.load_case(
            case_name=case_name,
            data_path=data_path,
            model_name=model_name,
            output_dir=output_dir,
            target_col=target_col,
            feature_cols=feature_cols,
            scoring=scoring,
        )
        classifier.run(param_grid=param_grid)
        classifier.collect_data()
        classifier.plot()
    # ==========================================================


if __name__ == "__main__":
    main()
