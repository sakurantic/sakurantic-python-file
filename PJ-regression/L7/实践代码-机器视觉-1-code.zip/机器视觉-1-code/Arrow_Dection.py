import cv2
import numpy as np
import os
from os import path

#! 关键函数，计算相似得分
def Array_Detect(mod_img,target_img):
    # 主要调整这个计算分数
    result = cv2.matchTemplate(target_img, mod_img, cv2.TM_SQDIFF)
    return result[0][0]

mod_img_pathes = ["./fig/mod_1.jpg","./fig/mod_2.jpg","./fig/mod_3.jpg","./fig/mod_4.jpg"] # 读取图像路径
result = ["up", "right", "down", "left"]
target_img_path = "./fig/target_0.jpg"
mod_imgs = []

# 读取所有模板图像并转换为灰度
for mod_img_path in mod_img_pathes:
    mod_img = cv2.imread(mod_img_path)
    mod_img = cv2.cvtColor(mod_img, cv2.COLOR_BGR2GRAY) # 需要转换为灰度图
    mod_img = np.float32(mod_img)/255
    mod_imgs.append(mod_img)

# 读取目标图像并转换为灰度
target_img = cv2.imread(target_img_path)
target_img = cv2.cvtColor(target_img, cv2.COLOR_BGR2GRAY) # 需要转换为灰度图
# 调整大小
target_img = cv2.resize(target_img,mod_imgs[0].shape,interpolation=cv2.INTER_LINEAR)
target_img = np.float32(target_img)/255
# print(mod_img[0])

# 循环进行匹配
scores = []
for mod_img in mod_imgs:
    #! 如果写了新的匹配函数在这里修改
    scores.append(Array_Detect(mod_img,target_img))

#! 注意这里不一定分数越小越好
best_arg = np.argmin(np.array(scores))
print(scores)
print("最优分数：",scores[best_arg])
print("匹配结果：",result[best_arg])
